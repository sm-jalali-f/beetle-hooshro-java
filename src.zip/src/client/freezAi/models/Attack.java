package client.freezAi.models;

import client.World;
import client.model.Beetle;

/**
 * Created by mohamad on 3/8/17.
 */
public class Attack {

    Beetle atackBeetle;
    public Attack(World game,Beetle btl) {
        this.atackBeetle =btl;
    }


}
